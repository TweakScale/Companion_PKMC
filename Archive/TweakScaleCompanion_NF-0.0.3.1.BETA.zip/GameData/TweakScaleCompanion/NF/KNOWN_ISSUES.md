# TweakScale Companion :: Near Future Add'Ons :: Known Issues

* Near Future Solar
	+ The following parts are not scalable under the current version of TweakScale due lack of Module Part Variant with mass:
		- nfs-panel-deploying-curved-25-1
		- nfs-panel-static-truss-1
		- nfs-panel-static-truss-2
		- nfs-panel-static-truss-3.
		- nfs-panel-deploying-blanket-starship-1
