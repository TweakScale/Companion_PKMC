# TweakScale Companion :: Near Future Add'Ons :: Change Log

* 2020-0726: 0.0.3.1 (Lisias) for KSP >= 1.4
	+ Patches revision.
		- Missing parts added
		- Reorganisation
		- Double checking with the lint tool.
* 2020-0614: 0.0.3.0 (Lisias) for KSP >= 1.4
	+ Added support for:
		- Near Future Aeronautics 
		- Near Future Construction
		- Near Future Electrical
		- Near Future Exploration
		- Near Future Construction
		- Near Future Launch Vehicles
		- Near Future Propulsion
		- Near Future SpaceCraft
* 2020-0511: 0.0.2.1 (Lisias) for KSP >= 1.4
	+ One more mistake fixed.
* 2020-0507: 0.0.2.0 (Lisias) for KSP >= 1.4
	+ Lots of mistakes fixed
	+ Added back legacy NFS support 
* 2020-0403: 0.0.1.1 (Lisias) for KSP >= 1.4 & NFS >= 1.1
	+ Renamed the package to TweakScaleCompanion_NF
* 2020-0112: 0.0.1.0 (Lisias) for KSP >= 1.4 * NFS >= 1.1
	+ Initial beta version for testing
