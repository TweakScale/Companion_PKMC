# TweakScale Companion :: Post Kerbin Mining Corporation Add'Ons :: Known Issues

* All
	+ As from 2021-xxxx, this Companion was rebranded as `TweakScale Companion for Post Kebin Mining Corporation`.
		- The previously distributions branded `TweakScale Companion for Near Future` shuold not be used anymore.
* Near Future Solar
	+ The following parts are not scalable under TweakScale 2.4.3.x or older due lack of Module Part Variant with mass:
		- nfs-panel-deploying-curved-25-1
		- nfs-panel-static-truss-1
		- nfs-panel-static-truss-2
		- nfs-panel-static-truss-3.
		- nfs-panel-deploying-blanket-starship-1
