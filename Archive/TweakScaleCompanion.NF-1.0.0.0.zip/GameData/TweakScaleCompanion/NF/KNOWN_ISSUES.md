# TweakScale Companion :: Near Future Add'Ons :: Known Issues

* All
	+ Please note that you will need the absolutely latest TweakScale 2.5 Beta or the (hopefully) near 2.4.4.0 as the patches were heavily reworked, adding or changing Scale types and exponents.
		+ otherwise ongoing savegames will be probably corrupted, as only the newer TS versions know how to overcome the KSP "automatic updating" that was rendering TS's scaling fixes useless in the past.
* Near Future Solar
	+ The following parts are not scalable under TweakScale 2.4.3.x or older due lack of Module Part Variant with mass:
		- nfs-panel-deploying-curved-25-1
		- nfs-panel-static-truss-1
		- nfs-panel-static-truss-2
		- nfs-panel-static-truss-3.
		- nfs-panel-deploying-blanket-starship-1
