# TweakScale Companion :: Near Future Add'Ons :: Change Log

* 2020-0403: 0.0.1.1 (Lisias) for KSP >= 1.4 & NFS >= 1.1
	+ Renamed the package to TweakScaleCompanion_NF
* 2020-0112: 0.0.1.0 (Lisias) for KSP >= 1.4 * NFS >= 1.1
	+ Initial beta version for testing
